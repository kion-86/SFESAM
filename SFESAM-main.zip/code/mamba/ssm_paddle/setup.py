from setuptools import setup

setup(
    name = 'mamba_ssm_paddle',
    version='0.0.0',
    description='mamba custom ops',
    author_email="yujun06@baidu.com",
    maintainer="PaddlePaddle",
    project_urls={},
    package_dir = {
        '': 'src',
    },
)