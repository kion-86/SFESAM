import paddle
from vmamba import SS2D, VSSBackbone

print("test SS2D")
x = paddle.rand([1, 64, 64, 128]).cuda()
print("input shape is ", x.shape)
m = SS2D(d_model=128).to('gpu:0')
y = m(x)
print("output shape is ", x.shape)

# x = paddle.rand([1, 3, 512, 512]).cuda()
# m = VSSBackbone().to('gpu:0')
# y = m(x)
# for i in y:
#     print(i.shape)